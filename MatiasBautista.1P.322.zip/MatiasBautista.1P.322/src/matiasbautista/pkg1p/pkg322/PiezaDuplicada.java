
package matiasbautista.pkg1p.pkg322;


public class PiezaDuplicada extends Exception{
    public PiezaDuplicada(String mensaje) {
        super(mensaje);
        
    }
}