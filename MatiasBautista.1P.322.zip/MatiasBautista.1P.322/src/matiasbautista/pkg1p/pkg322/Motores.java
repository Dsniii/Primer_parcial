
package matiasbautista.pkg1p.pkg322;

public class Motores extends  Pieza implements Ajustable {
    
    private double potenciaMaxima;

    public Motores(String nombre, String ubicacion, CondicionClimatica condicion, double potenciaMaxima) {
        super(nombre, ubicacion, condicion); 
        this.potenciaMaxima = potenciaMaxima;
    }

    public double getPotenciaMaxima() {
        return potenciaMaxima;
    }

    @Override
    public void ajustar() {
        System.out.println("Ajustando motor " + getNombre() + " a potencia optima.");
    }

    @Override
    public String toString() {
        return super.toString() + " Potencia Msxima: " + potenciaMaxima + " de HP";
    }
    
    
}
