
package matiasbautista.pkg1p.pkg322;


public interface Ajustable {
    void ajustar();
    
    
}
