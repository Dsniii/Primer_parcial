
package matiasbautista.pkg1p.pkg322;


public enum CondicionClimatica {
    
    SECO, 
    LLUVIA, 
    MIXTO
    
}
