
package matiasbautista.pkg1p.pkg322;


public class Neumaticos extends Pieza{
    
    
    private Compuesto compuesto;

    public Neumaticos(String nombre, String ubicacion, CondicionClimatica condicion, Compuesto compuesto) {
        super(nombre, ubicacion, condicion);
        this.compuesto = compuesto;
    }

    public Compuesto getCompuesto() {
        return compuesto;
    }

    @Override
    public String toString() {
        return super.toString() + " Compuesto: " + compuesto;
    }
    
    
    
}
