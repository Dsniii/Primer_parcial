
package matiasbautista.pkg1p.pkg322;


public enum Compuesto {

    SOFT, 
    MEDIUM, 
    HARD, 
    INTERMEDIO, 
    WET
}
